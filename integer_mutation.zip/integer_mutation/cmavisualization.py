import csv
import glob
import re
from os.path import exists
from math import ceil, floor, gcd, atan, degrees, sqrt

import numpy as np
from numpy.linalg import eigh
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib import gridspec, cm
from matplotlib.patches import Ellipse

def project_vec(vector_list, origin, v1, v2):
    """Project the list of 1D array onto the given subspace
    Parameters
    ----------
    vector_list : 2D iterable
        list of vectors to be projected
    origin : 1D iterable
        point in the original space projected into the origin
    v1, v2 : 1D iterable
        basis of 2D linear subspace
    Return
    ------
    2D array of projected vectors
    """
    vl = np.asarray(vector_list) - np.asarray(origin)
    x = np.dot(vl, v1)
    y = np.dot(vl, v2)
    return np.stack((x, y), axis=-1)

def project_cov(flatten_cov_list, v1, v2):
    """Project the list of flattened covariance matrix onto the given subspace
    Parameters
    ----------
    flatten_cov_list : 2D iterable
        list of row-major flattened covariance matrix to be projected
    v1, v2 : 1D iterable
        basis of 2D linear subspace
    Return
    ------
    2D array of flattened projected covariance matrix
    """
    
    N = len(v1)
    pinv = np.linalg.pinv(np.stack((v1, v2), axis=-1))
    xcov = np.asarray([np.dot(np.dot(pinv, vcov.reshape((N, N))), pinv.T).flatten() for vcov in flatten_cov_list])
    return xcov

def projected_func(func, origin, v1, v2):
    """Project function onto the given subspace
    Parameters
    ----------
    func : callable
        function defined in len(origin) dimensional space
    origin : 1D iterable
        point in the original space projected into the origin
    v1, v2 : 1D iterable
        basis of 2D linear subspace
    Return
    ------
    2D array of flattened projected covariance matrix
    """
    
    def subfunc(x):
        return func(origin + x[0] * v1 + x[1] * v2)
    return subfunc

def loaddatfrom(prefix, nheaderlines=1):
    """Load all log data starting from the given prefix
    Parameters
    ----------
    prefix : str
    nheaderlines : int, optional
        number of lines of header info in the log file
    Return
    ------
    dictionary of data
        key : variable name
        value : 2D iterable
    """
    assert exists(prefix+'_profile.dat'), 'log file not found.'
    datlist = glob.glob(prefix + '_*.dat')
    p = re.compile(prefix + '_(.*).dat')
    keylist = [p.findall(s)[0] for s in datlist]

    datdict = dict()
    for key in keylist:
        with open("{}_{}.dat".format(prefix, key)) as f:
            reader = csv.reader(f, delimiter=' ', quoting=csv.QUOTE_NONNUMERIC)
            for i in range(nheaderlines):
                header = next(reader)
            datdict[key] = np.asarray([np.asarray(row[3:]) for row in reader])
    return datdict

def extract_meshdata(filename, column_list, clip_filter_dict):
    """Extract the corresponding mesh data for contour plot
    Parameters
    ----------
    filename : str
    column_list : iterable (3 elements)
        indeces of columns corresponding to x, y, z axes
    clip_filter_dict : dict
        key : index of column
        value : iterable (2 elements) of min and max values to extract
    Return
    ------
    tuple (X, Y, Z) for pcolormesh
    """
    dat = np.loadtxt(filename)
    filter_ = np.ones(dat.shape[0], dtype=bool)
    for key in clip_filter_dict:
        filter_ *= clip_filter_dict[key][0] < dat[:, key]
        filter_ *= dat[:,key] < clip_filter_dict[key][1]
        dat = dat[filter_]

    idx = int(np.sqrt(dat.T[0].shape[0]))
    x = np.asarray([dat.T[column_list[0]][i * idx:( i + 1 ) * idx] for i in range(idx)])
    y = np.asarray([dat.T[column_list[1]][i * idx:( i + 1 ) * idx] for i in range(idx)])
    z = np.asarray([dat.T[column_list[2]][i * idx:( i + 1 ) * idx] for i in range(idx)])
    return x, y, z

class CmaVisualization:
    def __init__(self,
                 m_hist,
                 s_hist,
                 c_hist,
                 init_m,
                 init_s,
                 init_c=None,
                 x_hist=None,
                 f_hist=None,
                 func=None,
                 bg_mesh_data=None,
                 opt_point=None,
                 **var_hist_dict):
        '''CMA-ES Visualization Tool
        You can use this class to generate figures and animations of the search procedure of CMA-ESs.

        Required Parameters
        -------------------
        m_hist, s_hist, c_his t: 2D iterable
            history of Mean, Sigma, Covariance matrix
            Each row of the history is the values of m (vector), s ([scalar]), c (row-major flattened matrix)

        init_m, init_s : 1D iterable, scalar
            initial mean vector, step-size, and covariance matrix
        ---------------------

        Optional Parameters
        -------------------
        init_c : 1D iterable
            initial covariance matrix (row-major flattened)

        x_hist (optional), f_hist (optional) : 2D iterable
            history of candidate solutions (flattened) and their fitness values

        func: strings or function object
            objective function that you want to draw as background
            default: None
            The function must exist in the objective.py.
            If it's None, the background will be blank.
            
        bg_mesh_data : tuple of three 2D array
            mesh data (X, Y, Z) for pcolormesh
            The background contour image is set

        opt_point: ndarray
            coordinates of the optimal point
            default: None
        -----------------
        
        var_hist_dict : dict
            key = varialbe_name 
            value = 2D iterable of history of the variable
            Given variable histories are plotted.

        Note
        ----
        For the usage, see cmavisualization_samplescript.ipynb
        '''
        # Load data
        if init_c is None:
            init_c = [1.0, 0.0, 0.0, 1.0]
        self.m_array = np.vstack((np.asarray(init_m), m_hist))
        self.c_array = np.vstack((np.asarray(init_c), c_hist))
        self.s_array = np.vstack((np.array([init_s]), s_hist))
        self.x_array = None if x_hist is None else np.asarray(x_hist)
        self.f_array = None if f_hist is None else np.asarray(f_hist)
        # Flags
        self.flg_cb = False
        self.flg_xhist = False
        # Variables to be plotted
        self.var_dict = var_hist_dict
        # lim and iteration
        self._niter = 0
        self.maxiter = self.m_array.shape[0] - 1
        radius = 2.0 * self.s_array * np.sqrt(np.stack((self.c_array[:, 0], self.c_array[:, 3]), axis=-1))
        self.max_array = np.max(self.m_array + radius, axis=0)
        self.min_array = np.min(self.m_array - radius, axis=0)
        # Background
        self.func = func
        self.bg_mesh_data = bg_mesh_data
        self.opt_point = opt_point
        # Figure, axes, artists
        self.fig = None
        self.ax_proc = None
        self.ax_vars = {}
        self.ell_hist = []
        self.ell1 = None
        self.ell2 = None
        self.ell3 = None

    def fig_setting(self,
                    flg_init=True,
                    flg_xhist=False,
                    flg_cb=False,
                    margin=0,
                    focus='off',
                    xmax=None,
                    xmin=None,
                    ymax=None,
                    ymin=None,
                    **figure_kwargs):

        ## TODO: Bug: When 'flg_init' is 'False' and 'flg_var' is 'True', 'self._gs0.tight_layout(self.fig)' doesn't work well.
        assert focus in ('on', 'off', 'auto')
        self.focus = focus
        self.flg_cb = flg_cb
        self.flg_xhist = flg_xhist
        self.ax_vars = {}
        if xmax is not None:
            self.max_array[0] = xmax
        if ymax is not None:
            self.max_array[1] = ymax
        if xmin is not None:
            self.min_array[0] = xmin
        if ymin is not None:
            self.min_array[1] = ymin
        
        if isinstance(margin, int):
            self.margin_array = np.ones(2) * margin
        elif isinstance(margin, float):
            self.margin_array = (self.max_array - self.min_array)* margin
        elif isinstance(margin, list):
            self.margin_array = np.array(margin)
            float_idx = [isinstance(i, float) for i in margin]
            if any(float_idx):
                self.margin_array[float_idx] = (self.max_array[float_idx] - self.min_array[float_idx]) * self.margin_array[float_idx]
        self.xyratio = self.max_array - self.min_array + self.margin_array*2
        self.xyratio *= 5 / np.max(self.xyratio)
        self.xyratio = np.ceil(self.xyratio).astype(int)

        if flg_init or not self.fig:
            if not 'figsize' in figure_kwargs:
                if 'size_inches' in figure_kwargs:
                    figure_kwargs['figsize'] = figure_kwargs.pop('size_inches')
                elif self.var_dict:
                    figure_kwargs['figsize'] = tuple(self.xyratio + np.array([self.xyratio[1], 0]))
                else:
                    figure_kwargs['figsize'] = tuple(self.xyratio)
            plt.close()
            self.fig = plt.figure(**figure_kwargs)
        else:
            if 'figsize' in figure_kwargs:
                figure_kwargs['size_inches'] = figure_kwargs.pop('figsize')
            if not 'size_inches' in figure_kwargs:
                if self.var_dict:
                    figure_kwargs['size_inches'] = tuple(self.xyratio + np.array([self.xyratio[1], 0]))
                else:
                    figure_kwargs['size_inches'] = tuple(self.xyratio)
            self.fig.set(**figure_kwargs)
        if flg_init or not self.fig or self.var_dict:
            self.fig.clear()
            self.ax_proc = None
            self.ax_vars = {}
            if self.var_dict:
                minratio = (self.xyratio / gcd(self.xyratio[0], self.xyratio[1])).astype(int)
                self._gs0 = gridspec.GridSpec(1, minratio[0]+minratio[1])
                self._gs01 = gridspec.GridSpecFromSubplotSpec(len(self.var_dict), 1, subplot_spec=self._gs0[minratio[0]:])
                self.ax_proc = self.fig.add_subplot(self._gs0[:minratio[0]])
                self._indicators = {}
                for i, key in enumerate(self.var_dict):
                    self.ax_vars[key] = self.fig.add_subplot(self._gs01[i])
                    self.ax_vars[key].set_ylabel(key)
                    if i == len(self.var_dict) - 1:
                        self.ax_vars[key].set_xlabel('iteration')
                self._gs0.tight_layout(self.fig)
            else:
                self.ax_proc = self.fig.add_subplot(111)
            lb_array = self.min_array - self.margin_array
            ub_array = self.max_array + self.margin_array
            self.update_background(xlim=(lb_array[0], ub_array[0]), ylim=(lb_array[1], ub_array[1]), niter=0)

            for key in self.var_dict:
                if not key == 'xmean':
                    self.ax_vars[key].set_yscale('log')
                data = self.var_dict[key]
                self.ax_vars[key].plot(range(1, data.shape[0]+1), data)

    def get_figure(self):
        return self.fig

    def set_figure(self, fig):
        plt.close()
        self.fig = fig

    def save_figure(self, **savefig_kwargs):
        if not 'fname' in savefig_kwargs:
            print('Output file name `fname` not specified. `cmaes_figure.eps` is used.')
            savefig_kwargs['fname'] = 'cmaes_figure.eps'
        self.fig.savefig(**savefig_kwargs)

    def save_animation(self, start_niter=None, end_niter=None, **save_kwargs):
        if start_niter is None:
            start_niter = 0
        if end_niter is None:
            end_niter = self.maxiter
        if self.x_array is not None:
            self._niter = start_niter * 2 - 1
            nframe = end_niter * 2 - self._niter
        else:
            self._niter = start_niter - 1
            nframe = end_niter - self._niter
        if not 'filename' in save_kwargs:
            print('Output file name `filename` not specified. `cmaes_animation.mp4` is used.')
            save_kwargs['filename'] = 'cmaes_animation.mp4'
        ani = FuncAnimation(self.fig, self.draw, nframe)
        ani.save(**save_kwargs)

    def draw(self, _nf=None ,niter=None, focus=None):
        assert self.fig and self.ax_proc, "'self.fig' is empty. Please initialize it by 'fig_setting'."
        if focus:
            self.focus = focus
        if not niter:
            niter = self._niter
            self._niter += 1
        assert (niter <= self.maxiter and self.x_array is None) or (niter <= self.maxiter * 2 and self.x_array is not None), "It's over. If you want to play it again, please reset the iteration counter by 'reset_counter'."
        if not self.ax_proc.artists:
            lb_array = self.min_array - self.margin_array
            ub_array = self.max_array + self.margin_array
            self.update_background(xlim=(lb_array[0], ub_array[0]), ylim=(lb_array[1], ub_array[1]), niter=niter)
            self.cel3 = self.ax_proc.add_artist(Ellipse([0,0], 1, 1, facecolor='#33C490', edgecolor='#237480', alpha=0.6))
            self.cel2 = self.ax_proc.add_artist(Ellipse([0,0], 1, 1, facecolor='#33B490', edgecolor='#237480', alpha=0.6))
            self.cel1 = self.ax_proc.add_artist(Ellipse([0,0], 1, 1, facecolor='#33A490', edgecolor='#237480', alpha=0.6))

            for key in self.ax_vars:
                self._indicators[key], = self.ax_vars[key].plot(0,0, linestyle=':', linewidth=0.5, color='black')

        if self.x_array is not None:
            if niter % 2 == 0:
                # Update
                niter = niter // 2
                if hasattr(self, 'xscatter'):
                    self.xscatter.remove()

                if self.flg_xhist:
                    self.all_solutions_plot(max(0, niter-1), niter)

                m = self.m_array[niter]
                s = self.s_array[niter] * sqrt(2)
                C = self.c_array[niter].reshape((2,2))
                D, B = eigh(C)
                ev1 = B[0]
                wd = sqrt(D[0])
                hd = sqrt(D[1])
                angle = degrees(atan(ev1[1]/ev1[0]))

                flg_focus_change, xlim, ylim = self.get_right_focus(m, s, C)
                if flg_focus_change:
                    self.update_background(xlim, ylim, niter)
                    self.cel3 = self.ax_proc.add_artist(Ellipse([0,0], 1, 1, facecolor='#33C490', edgecolor='#237480', alpha=0.6))
                    self.cel2 = self.ax_proc.add_artist(Ellipse([0,0], 1, 1, facecolor='#33B490', edgecolor='#237480', alpha=0.6))
                    self.cel1 = self.ax_proc.add_artist(Ellipse([0,0], 1, 1, facecolor='#33A490', edgecolor='#237480', alpha=0.6))

                self.cel1.center = m
                self.cel1.width = s * wd
                self.cel1.height = s * hd
                self.cel1.angle = angle
                self.cel2.center = m
                self.cel2.width = s * wd * 2
                self.cel2.height = s * hd * 2
                self.cel2.angle = angle
                self.cel3.center = m
                self.cel3.width = s * wd * 3
                self.cel3.height = s * hd * 3
                self.cel3.angle = angle

                #self.x_line.set_visible(False)
                for key in self.ax_vars:
                    edges = self.ax_vars[key].get_ylim()
                    self._indicators[key].set_data(np.ones(2) * niter, edges)
            else:
                # Sampling
                niter = (niter - 1) // 2
                arf = self.f_array[niter]
                arx = self.x_array[niter].reshape((-1, 2))
                idx = np.argsort(arf)
                self.xscatter = self.ax_proc.scatter(arx[idx, 0], arx[idx, 1], c=np.arange(len(idx)), cmap='Greens_r', alpha=0.9, vmin=0, vmax=len(idx)-1, zorder=2)
        else:
            m = self.m_array[niter]
            s = self.s_array[niter] * sqrt(2)
            C = self.c_array[niter].reshape((2,2))
            D, B = eigh(C)
            ev1 = B[0]
            wd = sqrt(D[0])
            hd = sqrt(D[1])
            angle = degrees(atan(ev1[1]/ev1[0]))

            flg_focus_change, xlim, ylim = self.get_right_focus(m, s, C)
            if flg_focus_change:
                self.update_background(xlim, ylim, niter)
                self.cel3 = self.ax_proc.add_artist(Ellipse([0,0], 1, 1, facecolor='#33C490', edgecolor='#237480', alpha=0.6))
                self.cel2 = self.ax_proc.add_artist(Ellipse([0,0], 1, 1, facecolor='#33B490', edgecolor='#237480', alpha=0.6))
                self.cel1 = self.ax_proc.add_artist(Ellipse([0,0], 1, 1, facecolor='#33A490', edgecolor='#237480', alpha=0.6))


            self.cel1.center = m
            self.cel1.width = s * wd
            self.cel1.height = s * hd
            self.cel1.angle = angle
            self.cel2.center = m
            self.cel2.width = s * wd * 2
            self.cel2.height = s * hd * 2
            self.cel2.angle = angle
            self.cel3.center = m
            self.cel3.width = s * wd * 3
            self.cel3.height = s * hd * 3
            self.cel3.angle = angle

            for key in self.ax_vars:
                edges = self.ax_vars[key].get_ylim()
                self._indicators[key].set_data(np.ones(2)*niter, edges)

        self.fig.canvas.draw()

    def reset_counter(self,niter=None):
        if niter:
            self._niter = niter
        else:
            self._niter = 0

    def get_axes(self):
        return self.ax_proc, self.ax_vars

    def all_solutions_plot(self, start_iter, end_iter):
        xfil = self.xhist_filter[self.xhist_cumlam[start_iter]:self.xhist_cumlam[end_iter]]
        arx = self.xhist_arx[self.xhist_cumlam[start_iter]:self.xhist_cumlam[end_iter]]
        arf = self.xhist_arf[self.xhist_cumlam[start_iter]:self.xhist_cumlam[end_iter]]
        self.xhistscatterlist.append(self.ax_proc.scatter(
            arx[xfil, 0],
            arx[xfil, 1],
            c=arf[xfil],
            cmap=cm.coolwarm,
            alpha=0.2,
            vmin=self.xhist_arfmin,
            vmax=self.xhist_arfmax))

    def add_contour_from_func(self, func, xlim=None, ylim=None):
        assert self.fig, "Call 'fig_setting first'"
        if xlim is None:
            xlim = self.ax_proc.get_xlim()
        if ylim is None:
            ylim = self.ax_proc.get_ylim()
        x = np.linspace(xlim[0], xlim[1], self.xyratio[0] * 10)
        y = np.linspace(ylim[0], ylim[1], self.xyratio[1] * 10)
        X, Y = np.meshgrid(x, y)
        Z = np.array([self.func(np.asarray(v)) for v in zip(X.flatten(), Y.flatten())]).reshape(X.shape)
        cbg = self.ax_proc.contourf(X, Y, Z, cmap=cm.coolwarm, alpha=0.2)
        self.func = func
        return cbg

    def add_contour_from_meshdata(self, X, Y, Z, xlim=None, ylim=None):
        assert self.fig, "Call 'fig_setting first'"
        if xlim is None:
            xlim = (np.min(X), np.max(X)) # self.ax_proc.get_xlim()
        if ylim is None:
            ylim = (np.min(Y), np.max(Y)) # self.ax_proc.get_ylim()
        vmin = np.min(Z[(xlim[0] <= X) * (X <= xlim[1]) * (ylim[0] <= Y) * (Y <= ylim[1])])
        vmax = np.max(Z[(xlim[0] <= X) * (X <= xlim[1]) * (ylim[0] <= Y) * (Y <= ylim[1])])
        cbg = self.ax_proc.pcolormesh(X, Y, Z, cmap=cm.coolwarm, alpha=0.2, vmin=vmin, vmax=vmax)
        self.bg_mesh_data = (X, Y, Z)
        return cbg
        
    def update_background(self, xlim, ylim, niter):

        self.ax_proc.clear()
        ax = self.ax_proc
        # ax.set_xlabel('1st axis')
        # ax.set_ylabel('2nd axis')
        ax.set_xlim(xlim)
        ax.set_ylim(ylim)
        ax.set_aspect('equal')
        if self.bg_mesh_data is not None:  # Given Background Data
            self.cbg = self.add_contour_from_meshdata(*self.bg_mesh_data)
        elif self.func is not None:  # Function Contour
            self.cbg = self.add_contour_from_func(self.func)
        if self.opt_point is not None:
            self.ax_proc.plot(self.opt_point[0], self.opt_point[1], '*', markerfacecolor='#FFE000', markeredgecolor='#FF9000', alpha=0.8)
        if self.flg_cb:
            if hasattr(self, 'cb'):            
                self.cb.remove()
            _pos = self.ax_proc.get_position().get_points().flatten()
            cb_pos = [_pos[0] * 0.2 + _pos[2] * 0.8, _pos[1] + _pos[2] * 0.1, (_pos[2] - _pos[0]) * 0.1, (_pos[3]-_pos[1]) / 2 - (_pos[2] - _pos[0]) * 0.1]
            self.ax_cb = self.fig.add_axes(cb_pos)
            self.cb = plt.colorbar(self.cbg, cax=self.ax_cb)
        if self.flg_xhist:
            # Solution History
            lx, ux = xlim
            ly, uy = ylim
            if not hasattr(self, 'xhistscatterlist'):
                self.xhistscatterlist = []
                self.xhist_cumlam = np.cumsum([0] + [len(f) for f in self.f_array])
                self.xhist_arx = np.concatenate([np.asarray(x) for x in self.x_array]).reshape((-1, 2))
                self.xhist_arf = np.concatenate([np.asarray(f) for f in self.f_array])

            self.xhist_filter = (self.xhist_arx[:, 0] > lx) * (self.xhist_arx[:, 1] > ly) * (self.xhist_arx[:, 0] < ux) * (self.xhist_arx[:, 1] < uy)
            self.xhist_arfmin = self.xhist_arf[self.xhist_filter].min()
            self.xhist_arfmax = self.xhist_arf[self.xhist_filter].max()
            self.all_solutions_plot(start_iter=0, end_iter=niter)

    def get_right_focus(self, xmean, sigma, C):
        ax = self.ax_proc
        lx, ux = ax.get_xlim()
        ly, uy = ax.get_ylim()
        lb = np.array([lx, ly])
        ub = np.array([ux, uy])
        # Focus
        flg_focus_change = False
        if self.focus == 'on':
            radius = 4 * sigma * np.sqrt(np.diag(C))
            lb = xmean - radius.max()
            ub = xmean + radius.max()
            flg_focus_change = True
        elif self.focus == 'auto':
            radius = 2 * sigma * np.sqrt(np.diag(C))
            lbnew = xmean - radius.max()
            ubnew = xmean + radius.max()
            if (np.any(ub < ubnew) or
                np.any(lb > lbnew) or
                10 * radius.max() < np.max(ub - lb)):
                lb = lbnew - radius.max()
                ub = ubnew + radius.max()
                flg_focus_change = True
        return flg_focus_change, (lb[0], ub[0]), (lb[1], ub[1])



## Maybe 'set_axes' is not neccesary because a change of the axes returned by 'get_axes()' is reflected in 'self.fig' as soon as updating the axes.
## If you need 'set_axes', please uncomment the below lines and the 8th line, 'import matplotlib'.
## But I'm not sure wheather it works because I don't check it yet.
## by knishida Aug.9, 2017
#     def set_axes(self, ax_proc=None, ax_vars=None):
#         _flg_proc = isinstance(ax_proc, matplotlib.axes.SubplotBase)
#         _flg_vars = isinstance(ax_vars, dict) and all(isinstance(i, matplotlib.axes.SubplotBase) for i in ax_vars.values())
#         if _flg_proc:
#             self.fig.axes.remove(self.ax_proc)
#             self.ax_proc = ax_proc
#             self.fig.axes += [self.ax_proc]
#         if _flg_vars:
#             for key in ax_vars:
#                 self.fig.axes.remove(self.ax_vars[key])
#             self.ax_vars = ax_vars
#             self.fig.axes += self.ax_vars.values()
#         assert not ax_proc or _flg_proc, "'ax_proc' must be an instance of 'matplotlib.axes._subplots.AxesSubplot'. Please check it and try again."
#         assert not ax_vars or _flg_vars, "'ax_vars' must be a dictionary which has a parameter name as keys and instances of 'matplotlib.axes._subplots.AxesSubplot' as corresponding values. Please check it and try again."
